using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.world;

[GeneratedController("api/city/[action]")]
[Table("city", Schema = "world")]
[FastApiTable("world","mysql")]
public partial class city : BaseModel
{
    

    public string Name { get; set; } = null!;

    public string CountryCode { get; set; } = null!;

    public string District { get; set; } = null!;

    public int Population { get; set; }

    public virtual country CountryCodeNavigation { get; set; } = null!;
}

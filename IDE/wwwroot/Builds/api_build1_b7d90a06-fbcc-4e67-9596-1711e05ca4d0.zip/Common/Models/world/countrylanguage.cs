using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.world;

[GeneratedController("api/countrylanguage/[action]")]
[Table("countrylanguage", Schema = "world")]
[FastApiTable("world","mysql")]
public partial class countrylanguage : BaseModel
{
    public string CountryCode { get; set; } = null!;

    public string Language { get; set; } = null!;

    public string IsOfficial { get; set; } = null!;

    public float Percentage { get; set; }

    public virtual country CountryCodeNavigation { get; set; } = null!;
}

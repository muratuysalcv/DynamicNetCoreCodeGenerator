using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.test;

[GeneratedController("api/test/[action]")]
[Table("test", Schema = "dbo")]
[FastApiTable("test","postgre")]
public partial class test : BaseModel
{
    

    public string name { get; set; } = null!;

    public string? description { get; set; }
}

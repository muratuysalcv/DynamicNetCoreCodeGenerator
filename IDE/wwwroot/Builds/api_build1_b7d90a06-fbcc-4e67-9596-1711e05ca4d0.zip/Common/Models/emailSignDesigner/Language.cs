using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.emailSignDesigner;

[GeneratedController("api/Language/[action]")]
[Table("Language", Schema = "dbo")]
[FastApiTable("emailSignDesigner","mssql")]
public partial class Language : BaseModel
{
    

    public string Name { get; set; } = null!;

    public bool? Active { get; set; }
}

using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.emailSignDesigner;

[GeneratedController("api/Setting/[action]")]
[Table("Setting", Schema = "dbo")]
[FastApiTable("emailSignDesigner","mssql")]
public partial class Setting : BaseModel
{
    

    public string SettingKey { get; set; } = null!;

    public string? SettingValue { get; set; }
}

using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.emailSignDesigner;

[GeneratedController("api/SignTemplate/[action]")]
[Table("SignTemplate", Schema = "dbo")]
[FastApiTable("emailSignDesigner","mssql")]
public partial class SignTemplate : BaseModel
{
    

    public string Name { get; set; } = null!;

    public string Template { get; set; } = null!;

    public bool? Active { get; set; }

    public string? AvailableEmails { get; set; }
}

using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.emailSignDesigner;

[GeneratedController("api/EmailProgram/[action]")]
[Table("EmailProgram", Schema = "dbo")]
[FastApiTable("emailSignDesigner","mssql")]
public partial class EmailProgram : BaseModel
{
    

    public string Name { get; set; } = null!;

    public string Documentation { get; set; } = null!;
}

using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.sqlLiteFastApi;

[GeneratedController("api/api/[action]")]
[Table("api")]
[FastApiTable("sqlLiteFastApi","sqlite")]
public partial class api : BaseModel
{
    

    public string name { get; set; } = null!;

    public string? description { get; set; }

    public long active { get; set; }

    public string? host { get; set; }

    public long? user_id { get; set; }

    public long is_private { get; set; }
}

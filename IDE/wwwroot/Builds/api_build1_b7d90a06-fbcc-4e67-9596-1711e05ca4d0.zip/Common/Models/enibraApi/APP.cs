using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.enibraApi;

[GeneratedController("api/APP/[action]")]
[Table("APP", Schema = "MURAT")]
[FastApiTable("enibraApi","oracle")]
public partial class APP : BaseModel
{
    public string KEY { get; set; } = null!;

    public string NAME { get; set; } = null!;

    public string CONSTR { get; set; } = null!;

    public string API_KEY { get; set; } = null!;

    
}

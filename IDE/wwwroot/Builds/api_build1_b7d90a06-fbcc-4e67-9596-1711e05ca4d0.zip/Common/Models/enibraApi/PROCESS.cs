using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.enibraApi;

[GeneratedController("api/PROCESS/[action]")]
[Table("PROCESS", Schema = "MURAT")]
[FastApiTable("enibraApi","oracle")]
public partial class PROCESS : BaseModel
{
    public string KEY { get; set; } = null!;

    public string SQL { get; set; } = null!;

    public decimal RESULT_TYPE { get; set; }

    public decimal? ID { get; set; }
}

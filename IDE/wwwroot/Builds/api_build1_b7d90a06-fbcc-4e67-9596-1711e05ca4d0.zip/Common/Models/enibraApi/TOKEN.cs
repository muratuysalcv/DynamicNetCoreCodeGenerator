using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.enibraApi;

[GeneratedController("api/TOKEN/[action]")]
[Table("TOKEN", Schema = "MURAT")]
[FastApiTable("enibraApi","oracle")]
public partial class TOKEN : BaseModel
{
    public string SESSION_TOKEN { get; set; } = null!;

    public DateTime DATE_CREATE { get; set; }

    public DateTime? DATE_TIMEOUT { get; set; }

    public DateTime? DATE_END { get; set; }

    public string? REQUEST_PARAMS { get; set; }

    public string? APP_KEY { get; set; }

    
}

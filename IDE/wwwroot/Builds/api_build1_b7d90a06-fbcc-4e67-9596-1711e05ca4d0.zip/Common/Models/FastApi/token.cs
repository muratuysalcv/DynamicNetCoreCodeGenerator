using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.FastApi;

[GeneratedController("api/token/[action]")]
[Table("token", Schema = "dbo")]
[FastApiTable("FastApi","mssql")]
public partial class token : BaseModel
{
    

    public DateTime date_create { get; set; }

    public DateTime? date_end { get; set; }

    public string jwt { get; set; } = null!;

    public long user_id { get; set; }
}

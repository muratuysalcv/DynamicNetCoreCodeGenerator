using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.FastApi;

[GeneratedController("api/con_table/[action]")]
[Table("con_table", Schema = "dbo")]
[FastApiTable("FastApi","mssql")]
public partial class con_table : BaseModel
{
    

    public string name { get; set; } = null!;

    public string? description { get; set; }

    public bool? active { get; set; }

    public long con_id { get; set; }
}

using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.FastApi;

[GeneratedController("api/api/[action]")]
[Table("api", Schema = "dbo")]
[FastApiTable("FastApi","mssql")]
public partial class api : BaseModel
{
    

    public string name { get; set; } = null!;

    public string? description { get; set; }

    public bool? active { get; set; }

    public string? host { get; set; }

    public long user_id { get; set; }

    public bool? is_private { get; set; }

    public long? login_process_id { get; set; }

    public long? logout_process_id { get; set; }

    public string? jwt_issuer { get; set; }

    public string? jwt_audience { get; set; }

    public string? jwt_key { get; set; }

    public Guid uid { get; set; }

    public long api_code { get; set; }
}

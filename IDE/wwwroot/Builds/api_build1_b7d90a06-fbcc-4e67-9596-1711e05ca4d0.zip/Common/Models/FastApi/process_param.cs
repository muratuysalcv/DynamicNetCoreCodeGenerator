using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.FastApi;

[GeneratedController("api/process_param/[action]")]
[Table("process_param", Schema = "dbo")]
[FastApiTable("FastApi","mssql")]
public partial class process_param : BaseModel
{
    

    public string name { get; set; } = null!;

    public string data_type { get; set; } = null!;

    public int direction { get; set; }

    public int priority { get; set; }

    public string? description { get; set; }
}

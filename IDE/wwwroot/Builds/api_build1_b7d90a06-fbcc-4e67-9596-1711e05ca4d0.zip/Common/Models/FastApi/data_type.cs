using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.FastApi;

[GeneratedController("api/data_type/[action]")]
[Table("data_type", Schema = "dbo")]
[FastApiTable("FastApi","mssql")]
public partial class data_type : BaseModel
{
    

    public string name { get; set; } = null!;
}

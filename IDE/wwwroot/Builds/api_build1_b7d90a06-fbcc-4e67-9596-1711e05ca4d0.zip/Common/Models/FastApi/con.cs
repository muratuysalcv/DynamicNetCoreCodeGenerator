using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.FastApi;

[GeneratedController("api/con/[action]")]
[Table("con", Schema = "dbo")]
[FastApiTable("FastApi","mssql")]
public partial class con : BaseModel
{
    

    public string name { get; set; } = null!;

    public string? connection { get; set; }

    public int con_type_id { get; set; }

    public bool? active { get; set; }

    public long? user_id { get; set; }

    public string? db_source { get; set; }

    public string? db_user { get; set; }

    public string? db_password { get; set; }

    public string? db_name { get; set; }

    public int? db_port { get; set; }

    public string? db_schema { get; set; }

    public string? comment { get; set; }

    public long api_id { get; set; }

    public bool is_main { get; set; }

    public bool? is_scaffold { get; set; }
}

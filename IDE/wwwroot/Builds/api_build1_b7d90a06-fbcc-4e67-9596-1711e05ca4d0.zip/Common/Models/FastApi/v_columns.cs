using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.FastApi;

[GeneratedController("api/v_columns/[action]")]
[Table("v_columns", Schema = "dbo")]
[FastApiTable("FastApi","mssql")]
public partial class v_columns : BaseModel
{
    public string? Database_Name { get; set; }

    public string Schema_Name { get; set; } = null!;

    public string Table_Name { get; set; } = null!;

    public string? Column_Name { get; set; }

    public string Column_Data_Type { get; set; } = null!;

    public string Column_System_Type { get; set; } = null!;

    public short Column_Maximum_Length { get; set; }

    public byte Column_Precision { get; set; }

    public byte Column_Scale { get; set; }

    public string? Column_Has_Primary_Key { get; set; }

    public string? Column_Is_Nullable { get; set; }

    public string? Column_Has_Identity { get; set; }

    public string? Column_Is_Computed { get; set; }

    public string? Computed_Column_Definition { get; set; }

    public int Column_Id { get; set; }

    public int Is_System_Table { get; set; }
}

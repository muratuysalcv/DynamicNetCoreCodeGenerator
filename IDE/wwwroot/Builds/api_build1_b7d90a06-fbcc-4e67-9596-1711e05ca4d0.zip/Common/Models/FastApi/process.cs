using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.FastApi;

[GeneratedController("api/process/[action]")]
[Table("process", Schema = "dbo")]
[FastApiTable("FastApi","mssql")]
public partial class process : BaseModel
{
    

    public string name { get; set; } = null!;

    public string? description { get; set; }

    public string? sql { get; set; }

    public int con_id { get; set; }

    public bool? active { get; set; }

    public string? request { get; set; }

    public string? response { get; set; }
}

using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.FastApi;

[GeneratedController("api/v_primary_keys/[action]")]
[Table("v_primary_keys", Schema = "dbo")]
[FastApiTable("FastApi","mssql")]
public partial class v_primary_keys : BaseModel
{
    public string TABLENAME { get; set; } = null!;

    public string? PRIMARYKEYCOLUMN { get; set; }
}

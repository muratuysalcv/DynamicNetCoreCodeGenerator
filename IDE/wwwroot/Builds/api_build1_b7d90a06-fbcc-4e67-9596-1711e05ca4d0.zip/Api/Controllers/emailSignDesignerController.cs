using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Scriptingo.Common;
using Scriptingo.Models.emailSignDesigner;

namespace Scriptingo.FastApi.Controllers
{
    /// <summary>
    /// E-posta imza oluşturma aracının veri tabanıdır.
    /// </summary>
    public class emailSignDesignerCustomProcessController : Controller
    {
        public string SQL { get; set; }
        public FastApiSqlExecuterContext sqlExecuter { get; set; }
        public emailSignDesignerCustomProcessController()
        {
            sqlExecuter = new FastApiSqlExecuterContext(new ModelConfiguration("emailSignDesigner"));
        }



    }
}
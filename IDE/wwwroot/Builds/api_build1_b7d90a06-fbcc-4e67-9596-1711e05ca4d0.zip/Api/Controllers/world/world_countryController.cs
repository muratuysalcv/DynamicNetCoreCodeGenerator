using Microsoft.AspNetCore.Mvc;
using Scriptingo.Common;
using Scriptingo.Models.world;

namespace Scriptingo.FastApi.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    public class world_countryController : FastApiController<country>
    {

    }
}
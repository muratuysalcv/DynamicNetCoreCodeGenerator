using Microsoft.AspNetCore.Mvc;
using Scriptingo.Common;
using Scriptingo.Models.FastApi;

namespace Scriptingo.FastApi.Controllers
{
    /// <summary>
    /// Login için gerekli ana veritabanıdır.
    /// </summary>
    public class FastApi_userController : FastApiController<user>
    {

    }
}
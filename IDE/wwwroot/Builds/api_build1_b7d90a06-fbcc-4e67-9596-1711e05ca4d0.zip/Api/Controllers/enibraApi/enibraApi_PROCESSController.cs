using Microsoft.AspNetCore.Mvc;
using Scriptingo.Common;
using Scriptingo.Models.enibraApi;

namespace Scriptingo.FastApi.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    public class XE_PROCESSController : FastApiController<PROCESS>
    {

    }
}
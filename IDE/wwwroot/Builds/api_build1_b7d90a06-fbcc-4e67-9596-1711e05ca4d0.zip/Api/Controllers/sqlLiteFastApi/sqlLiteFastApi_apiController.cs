using Microsoft.AspNetCore.Mvc;
using Scriptingo.Common;
using Scriptingo.Models.sqlLiteFastApi;

namespace Scriptingo.FastApi.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    public class _apiController : FastApiController<api>
    {

    }
}
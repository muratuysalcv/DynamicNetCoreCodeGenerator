using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Scriptingo.Common;
using Scriptingo.Models.test;

namespace Scriptingo.FastApi.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    public class testCustomProcessController : Controller
    {
        public string SQL { get; set; }
        public FastApiSqlExecuterContext sqlExecuter { get; set; }
        public testCustomProcessController()
        {
            sqlExecuter = new FastApiSqlExecuterContext(new ModelConfiguration("test"));
        }



    }
}
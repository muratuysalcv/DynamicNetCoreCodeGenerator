using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Scriptingo.Common;
using Scriptingo.Models.sqlLiteFastApi;

namespace Scriptingo.FastApi.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    public class sqlLiteFastApiCustomProcessController : Controller
    {
        public string SQL { get; set; }
        public FastApiSqlExecuterContext sqlExecuter { get; set; }
        public sqlLiteFastApiCustomProcessController()
        {
            sqlExecuter = new FastApiSqlExecuterContext(new ModelConfiguration("sqlLiteFastApi"));
        }



    }
}
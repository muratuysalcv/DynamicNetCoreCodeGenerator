using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Scriptingo.Common;
using Scriptingo.Models.world;

namespace Scriptingo.FastApi.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    public class worldCustomProcessController : Controller
    {
        public string SQL { get; set; }
        public FastApiSqlExecuterContext sqlExecuter { get; set; }
        public worldCustomProcessController()
        {
            sqlExecuter = new FastApiSqlExecuterContext(new ModelConfiguration("world"));
        }

        /// <summary>
        /// Test tablosundan veri siler.
        /// </summary>
        [HttpPost("delete")]
        public ContentResult delete([FromBody] ApiRequest req)
        {
            var response = new ApiReturn();
            this.SQL = @"delete from test where id = @id --12356";
            try
            {
                if (req.WithData)
                {
                    var dt = sqlExecuter.ExecuteDataSql(this.SQL, req.Parameters);
                    var json = response.jsonFromDatatable(dt);
                    return Content(json, "application/json");
                }
                else
                {
                    sqlExecuter.ExecuteSql(this.SQL, req.Parameters);
                }
            }
            catch (Exception ex)
            {

                response.status = "exception";
                response.message = ex.Message;
            }
            return Content(JsonConvert.SerializeObject(response),"application/json");
        }

        /// <summary>
        /// Country listesini getirir.
        /// </summary>
        [HttpPost("GetAllCountryList")]
        public ContentResult GetAllCountryList([FromBody] ApiRequest req)
        {
            var response = new ApiReturn();
            this.SQL = @"select * from Country;";
            try
            {
                if (req.WithData)
                {
                    var dt = sqlExecuter.ExecuteDataSql(this.SQL, req.Parameters);
                    var json = response.jsonFromDatatable(dt);
                    return Content(json, "application/json");
                }
                else
                {
                    sqlExecuter.ExecuteSql(this.SQL, req.Parameters);
                }
            }
            catch (Exception ex)
            {

                response.status = "exception";
                response.message = ex.Message;
            }
            return Content(JsonConvert.SerializeObject(response),"application/json");
        }

        /// <summary>
        /// Yeni bir test kaydı oluşturur.
        /// </summary>
        [HttpPost("create")]
        public ContentResult create([FromBody] ApiRequest req)
        {
            var response = new ApiReturn();
            this.SQL = @"insert into test(name,description) values(@name,@description) ; insert into test(name,description) values(@name,@description);";
            try
            {
                if (req.WithData)
                {
                    var dt = sqlExecuter.ExecuteDataSql(this.SQL, req.Parameters);
                    var json = response.jsonFromDatatable(dt);
                    return Content(json, "application/json");
                }
                else
                {
                    sqlExecuter.ExecuteSql(this.SQL, req.Parameters);
                }
            }
            catch (Exception ex)
            {

                response.status = "exception";
                response.message = ex.Message;
            }
            return Content(JsonConvert.SerializeObject(response),"application/json");
        }

        /// <summary>
        /// test tablolarının name alanını ok e çevirir.
        /// </summary>
        [HttpPost("to_ok")]
        public ContentResult to_ok([FromBody] ApiRequest req)
        {
            var response = new ApiReturn();
            this.SQL = @"";
            try
            {
                if (req.WithData)
                {
                    var dt = sqlExecuter.ExecuteDataSql(this.SQL, req.Parameters);
                    var json = response.jsonFromDatatable(dt);
                    return Content(json, "application/json");
                }
                else
                {
                    sqlExecuter.ExecuteSql(this.SQL, req.Parameters);
                }
            }
            catch (Exception ex)
            {

                response.status = "exception";
                response.message = ex.Message;
            }
            return Content(JsonConvert.SerializeObject(response),"application/json");
        }



    }
}
using Microsoft.AspNetCore.Mvc;
using Scriptingo.Common;
using Scriptingo.Models.test;

namespace Scriptingo.FastApi.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    public class test_testController : FastApiController<test>
    {

    }
}
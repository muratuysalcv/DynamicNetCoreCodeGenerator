using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.emailSignDesigner;

[GeneratedController("api/Translate/[action]")]
[Table("Translate", Schema = "dbo")]
[FastApiTable("emailSignDesigner","mssql")]
public partial class Translate : BaseModel
{
    

    public int LanguageId { get; set; }

    public string Word { get; set; } = null!;

    public string Meaning { get; set; } = null!;
}

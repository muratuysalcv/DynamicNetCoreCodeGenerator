using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.enibraApi;

[GeneratedController("api/PROCESS_LOG/[action]")]
[Table("PROCESS_LOG", Schema = "MURAT")]
[FastApiTable("enibraApi","oracle")]
public partial class PROCESS_LOG : BaseModel
{
    public string NAME { get; set; } = null!;

    public string DESCRIPTION { get; set; } = null!;

    public DateTime DATE_CREATE { get; set; }

    public string APP_KEY { get; set; } = null!;

    public string USER_ID { get; set; } = null!;

    
}

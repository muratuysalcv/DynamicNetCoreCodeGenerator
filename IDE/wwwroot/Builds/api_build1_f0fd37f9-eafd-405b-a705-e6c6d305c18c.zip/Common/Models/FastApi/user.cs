using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.FastApi;

[GeneratedController("api/user/[action]")]
[Table("user", Schema = "dbo")]
[FastApiTable("FastApi","mssql")]
public partial class user : BaseModel
{
    

    public string first_name { get; set; } = null!;

    public string last_name { get; set; } = null!;

    public string e_mail { get; set; } = null!;

    public int status { get; set; }

    public string password { get; set; } = null!;

    public Guid uid { get; set; }

    public int wrong_try { get; set; }

    public string? temp_code { get; set; }

    public string? jwt_token { get; set; }
}

using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.FastApi;

[GeneratedController("api/lang/[action]")]
[Table("lang", Schema = "dbo")]
[FastApiTable("FastApi","mssql")]
public partial class lang : BaseModel
{
    

    public string? name { get; set; }

    public string? culture_code { get; set; }
}

using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.FastApi;

[GeneratedController("api/word/[action]")]
[Table("word", Schema = "dbo")]
[FastApiTable("FastApi","mssql")]
public partial class word : BaseModel
{
    

    public string? word1 { get; set; }

    public string? value { get; set; }

    public string? language { get; set; }
}

using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.FastApi;

[GeneratedController("api/api_build/[action]")]
[Table("api_build", Schema = "dbo")]
[FastApiTable("FastApi","mssql")]
public partial class api_build : BaseModel
{
    

    public DateTime date_build { get; set; }

    public long build_number { get; set; }

    public long api_id { get; set; }

    public long builder_user_id { get; set; }

    public string build_dir { get; set; } = null!;

    public DateTime? date_build_start { get; set; }

    public DateTime? date_build_end { get; set; }

    public Guid build_uid { get; set; }
}

using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.FastApi;

[GeneratedController("api/api_doc/[action]")]
[Table("api_doc", Schema = "dbo")]
[FastApiTable("FastApi","mssql")]
public partial class api_doc : BaseModel
{
    

    public string name { get; set; } = null!;

    public string? description { get; set; }
}

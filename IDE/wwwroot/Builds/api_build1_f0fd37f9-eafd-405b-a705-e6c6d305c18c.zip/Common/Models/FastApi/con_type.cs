using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.FastApi;

[GeneratedController("api/con_type/[action]")]
[Table("con_type", Schema = "dbo")]
[FastApiTable("FastApi","mssql")]
public partial class con_type : BaseModel
{
    

    public string name { get; set; } = null!;

    public string? description { get; set; }

    public string? con_str_format { get; set; }
}

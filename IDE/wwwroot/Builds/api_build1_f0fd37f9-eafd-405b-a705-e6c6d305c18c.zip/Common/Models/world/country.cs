using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations.Schema;
using Scriptingo.Common;

namespace Scriptingo.Models.world;

[GeneratedController("api/country/[action]")]
[Table("country", Schema = "world")]
[FastApiTable("world","mysql")]
public partial class country : BaseModel
{
    public string Code { get; set; } = null!;

    public string Name { get; set; } = null!;

    public string Continent { get; set; } = null!;

    public string Region { get; set; } = null!;

    public float SurfaceArea { get; set; }

    public short? IndepYear { get; set; }

    public int Population { get; set; }

    public float? LifeExpectancy { get; set; }

    public float? GNP { get; set; }

    public float? GNPOld { get; set; }

    public string LocalName { get; set; } = null!;

    public string GovernmentForm { get; set; } = null!;

    public string? HeadOfState { get; set; }

    public int? Capital { get; set; }

    public string Code2 { get; set; } = null!;

    public virtual ICollection<city> city { get; } = new List<city>();

    public virtual ICollection<countrylanguage> countrylanguage { get; } = new List<countrylanguage>();
}

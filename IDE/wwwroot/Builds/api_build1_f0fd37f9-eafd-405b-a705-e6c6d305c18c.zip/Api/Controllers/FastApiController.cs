using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Scriptingo.Common;
using Scriptingo.Models.FastApi;

namespace Scriptingo.FastApi.Controllers
{
    /// <summary>
    /// Login için gerekli ana veritabanıdır.
    /// </summary>
    public class FastApiCustomProcessController : Controller
    {
        public string SQL { get; set; }
        public FastApiSqlExecuterContext sqlExecuter { get; set; }
        public FastApiCustomProcessController()
        {
            sqlExecuter = new FastApiSqlExecuterContext(new ModelConfiguration("FastApi"));
        }



    }
}
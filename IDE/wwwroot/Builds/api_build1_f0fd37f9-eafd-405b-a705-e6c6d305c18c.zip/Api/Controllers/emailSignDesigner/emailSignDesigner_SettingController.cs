using Microsoft.AspNetCore.Mvc;
using Scriptingo.Common;
using Scriptingo.Models.emailSignDesigner;

namespace Scriptingo.FastApi.Controllers
{
    /// <summary>
    /// E-posta imza oluşturma aracının veri tabanıdır.
    /// </summary>
    public class emailSignDesigner_SettingController : FastApiController<Setting>
    {

    }
}